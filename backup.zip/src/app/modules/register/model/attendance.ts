export class Attendance {
    id?: number;
    studentId: String =''
    status: Number;

  }
  