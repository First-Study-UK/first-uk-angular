import { InvoiceService } from 'src/app/shared/services/invoice.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-income',
  templateUrl: './income.component.html',
  styleUrls: ['./income.component.css']
})
export class IncomeComponent implements OnInit {

  items = [{icon:"pi pi-home",label:'Income'}];
  allInvoice:any;
  totalIncome:any


  constructor( private invoice: InvoiceService) { }

  ngOnInit(): void {
    this.invoice.getInvoice().subscribe(data => 
      {
        return this.allInvoice = data,
        this.totalIncome = data.reduce((acc, cc) => acc + cc.totalPayable,0)
       }
      );
  }


}
