import { CoursesService } from 'src/app/shared/services/courses.service';
import { TeacherService } from 'src/app/shared/services/teacher.service';
import { Router } from '@angular/router';

import { StudentService } from 'src/app/shared/services/student.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, FormBuilder } from '@angular/forms';




@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {
 

  maxDateValue = new Date();
  studentID = this.createId()
  students:any
  dates:any
  displayBasic2: boolean;
  scheduleTime:any
  selectedscheduleTime:any
  scheduleDay:any
  selectedscheduleDay:any
  tutors:any
  selectedTutors:any
  day:any
  selectedDay:any
  subjects:any
  subSubjects:any

  constructor(
    private StudentService: StudentService,
    private formbuilder: FormBuilder,
    private router :Router,
    private teacherService:TeacherService,
    private subjectservice : CoursesService
    ) {
    this.yearGroup = [
    {name: "Year 01",code:"01"},
    {name: "Year 02",code:"02"},
    {name: "Year 03",code:"03"},
    {name: "Year 04",code:"04"},
    {name: "Year 05",code:"05"},
    {name: "Year 06",code:"06"},
    ],
    this.gender = [
    {name: "male",code:"01"},
    {name: "female",code:"02"},
    {name: "other",code:"03"},
    ]
    this.day = [
      {name: "Sunday",code:"01"},
      {name: "Monday",code:"02"},
      {name: "Tuesday",code:"03"},
      {name: "Wednesday",code:"04"},
      {name: "Thusday",code:"05"},
      {name: "Friday",code:"06"},
      {name: "Saturday",code:"07"},
      ]
}


ngOnInit(): void {
  this.StudentService.getlAllStudent().subscribe(students => {
   this.students = students;
  //  this.studentID = `FS100${students.length + 1}`
    });
    this.teacherService.getAllteachers().subscribe(teacherData => {
      this.tutors = teacherData.map((item)=> {
        return {
          name: item.teacherInfo.fullName,
          code : item.teacherInfo.teacherId
        }
      })
      });

  this.subjectservice.getSubjects().subscribe(res=>{
        this.subjects = res.map((item)=> {
          return {
            name: item.subjectName,
            code : item.id
          }
        })
        this.subSubjects = res.map((item)=> {
          return {
            name: item.subSubject,
            code : item.id
          }
        })
      })
      
  }
  
  // deleteRow(index: number) {
  //   this.formArr.removeAt(index);
  // }

  displayPersonal= false;
  displayAcademic= false;
  displayOthers= false;
  class:any;
  yearGroup:any;
  tutor:any;
  selectedInfo: any;
  infoList = [];
  gender:any;
  scday:any;
  sctime:any;
  subject:any;
  subsubject:any;

  // for random id
  createId(): string {
    let id = 'FS-';
    var chars = '0123456789';
    for ( var i = 0; i < 5; i++ ) {
        id += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return id;
}
 

  addStudent = new FormGroup({ 
    fullname: new FormControl(''),
    studentId: new FormControl(`${this.studentID}`),
    birthdate: new FormControl(''),
    gender: new FormControl(''),
    mobile: new FormControl(''),
    email: new FormControl(''),
    address: new FormControl(''),
    street: new FormControl(''),
    postcode: new FormControl(''),
    enroldate: new FormControl(''),
    
    yeargroup: new FormControl(''),
    contact1: new FormControl(''),
    mbl1: new FormControl(''),
    emailp1: new FormControl(''),
    contact2: new FormControl(''),
    mbl2: new FormControl(''),
    emailp2: new FormControl(''),
    allergy: new FormControl(''),
    medical: new FormControl(''),
    learning: new FormControl('')
  });


  // "studentId": "string",
  // "subject": "string",
  // "subSubject": "string",
  // "tutorName": "string",
  // "scheduleDay": "string",
  // "scheduleTime": "string",
  // "teacherId": "string"

  selectedSubject = new FormGroup({
    studentId: new FormControl(`${this.studentID}`),
    tutorName:new FormControl('ud'),
    scheduleDay:  new FormControl(''),
    scheduleTime:  new FormControl(''),
    subject:  new FormControl(''),
    subSubject:  new FormControl(''),
    teacherId:  new FormControl(''),
  })

  addMore(){
    this.selectedInfo = this.selectedSubject.value;
    this.infoList.push(this.selectedInfo);
    console.log(this.infoList) 
  }

  onSubmit(){
    this.StudentService.PostStudentData(this.addStudent.value , this.infoList)
    .subscribe(res => {
      this.router.navigate(['/students']);
      this.displayBasic2= false
      console.log(res);
    })
  }
}