import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { InvoiceService} from 'src/app/shared/services/invoice.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-invoice-print',
  templateUrl: './new-invoice.component.html',
  styleUrls: ['./new-invoice.component.css']
})

export class NewInvoiceComponent implements OnInit {
// breadcrumb
items = [{icon:"pi pi-home",label:'New Invoice'}];
calenderValue :''
currency:''
discount:''
returnUrl: "/dashboard"
displayBasic2 : any

paymentMethods:any;
selectedPaymentMethods:any ;

paymentStatus:any;
selectedPaymentStatus:any ;

autoResize: 300
recentPayment :[]

displayDownload : any

constructor(private invoice: InvoiceService,private router: Router) {
  this.paymentMethods = [
    {name: 'Paypal',code: 'p1'},
    {name: 'Payoneer',code: 'p2'},
];
this.paymentStatus = [
  {name: 'Paid', code: 'p1'},
  {name: 'Cash', code: 'p2'},
];

 }


 showBasicDialog2(){
  this.displayBasic2 = true
 }

 showDownloadDialog(){
  this.displayDownload = true
 }
ngOnInit() {
   
}
addInvoice = new FormGroup({
  studentId: new FormControl(''),
  studentName: new FormControl(''),
  enrolmentDate: new FormControl(''),
  endDate: new FormControl(''),
  fees: new FormControl(''),
  totalPayable: new FormControl(''),
  discount: new FormControl(''),
  paymentMethod: new FormControl(''),
  status: new FormControl(''),
  invoiceId: new FormControl(''),
  Note: new FormControl('')
})
onSubmit(){
  this.invoice.PostInvoice(this.addInvoice.value)
  .subscribe(res => {
    this.displayBasic2= false
    this.router.navigate(['/accounts']);
  })
}

discountPercent(e){
  console.log(e)
 }
}
