
import { InvoiceService } from 'src/app/shared/services/invoice.service';
import { Component, OnInit } from '@angular/core';
import { StudentService } from 'src/app/shared/services/student.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-invoice-print',
  templateUrl: './invoice-print.component.html',
  styleUrls: ['./invoice-print.component.css']
})
export class InvoicePrintComponent implements OnInit {
  // breadcrumb
  items = [{icon:"pi pi-home",label:'Download'}];
  displayBasic2 : any
  singleStudentPayment:any
  allStudentsData:any


  constructor(private route: ActivatedRoute, private StudentService: StudentService,private invoice: InvoiceService ) { }

  ngOnInit(): void {
    this.route.params.subscribe((params:any) => {
      this.invoice.getIndividualPaymentInvoice(params.id).subscribe((sudentdata)=>{
        this.singleStudentPayment = sudentdata  
      })
  });

  this.StudentService.getlAllStudent().subscribe((studentsdata)=>{
     this.allStudentsData = studentsdata 
  })
  }

  showBasicDialog2(){
    this.displayBasic2 = true
   }

   exportExcel() {
    import("xlsx").then(xlsx => {
      const worksheet = xlsx.utils.json_to_sheet(this.allStudentsData);
      const workbook = { Sheets: { data: worksheet }, SheetNames: ["data"] };
      const excelBuffer: any = xlsx.write(workbook, {
        bookType: "xlsx",
        type: "array"
      });
      this.saveAsExcelFile(excelBuffer, "products");
    });
  }

//   exportPdf() {
//     import("jspdf").then(jsPDF => {
//         import("jspdf-autotable").then(x => {
//             const doc = new jsPDF.default(0,0);
//             doc.autoTable(this.exportColumns, this.products);
//             doc.save('products.pdf');
//         })
//     })
// }

  saveAsExcelFile(buffer: any, fileName: string): void {
    import("file-saver").then(FileSaver => {
      let EXCEL_TYPE =
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
      let EXCEL_EXTENSION = ".xlsx";
      const data: Blob = new Blob([buffer], {
        type: EXCEL_TYPE
      });
      FileSaver.saveAs(
        data,
        fileName + "_export_" + new Date().getTime() + EXCEL_EXTENSION
      );
    });
  }
}
