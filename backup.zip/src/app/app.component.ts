import { AuthService } from 'src/app/shared/services/auth.service';
import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: []
})
export class AppComponent {
  title = 'First Study';
  currentuser : any

  constructor(public authService : AuthService){ }
  ngOnInit(){
    console.log( JSON.parse(localStorage.getItem('token')))
    // this.currentuser = this.authService
    // this.currentuser = JSON.parse(localStorage.getItem('token'));
  }
}
