import { Component, OnInit } from '@angular/core';
import {MenuItem} from 'primeng/api';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth.service';

@Component({
  selector: 'app-menubar',
  templateUrl: './menubar.component.html',
  styleUrls: ['./menubar.component.css']
})
export class MenubarComponent implements OnInit {


  status:any = true
  items:MenuItem[] = []

  constructor(private router: Router,public authService : AuthService) {}
  checkActiveState(givenLink) {
    console.log(this.router.url);
    if (this.router.url.indexOf(givenLink) === -1) {
      return false;
    } else {
      return true;
    }
  }

  ngOnInit() {

      this.items = [
          {
          label: 'Dashboard',
          icon:'pi pi-th-large',
          routerLink:["/dashboard"],
          expanded: this.checkActiveState("/dashboard"),
          styleClass:"active",

          },
          {
          label: 'Students',
          icon:'pi pi-users',
         
          items: [
              {
                  label: 'Add Students',
                  icon:'pi pi-user-plus',
                  routerLink:["/addstudent"],
                  
              },
              {
                  label: 'All Students',
                  icon:'pi pi-user',
                  routerLink:["/students"]
              },
          ]
          },
          {
          label: 'Teachers',
          icon:'pi pi-user',
          items: [
            {
                label: 'Add Teacher',
                icon:'pi pi-user-plus',
                routerLink:["/addteacher"],
            },
            {
                label: 'All Teacher',
                icon:'pi pi-user',
                routerLink:["/teachers"],
            },
          ]
          },
          {
            label: 'Subjects',
            icon:'pi pi-book',
            routerLink:["/subjects"],
            
            },
            {
                label: 'TimeTable',
                icon:'pi pi-book',
                routerLink:["/timetable"],
                },

                {
                    label: 'Accounts',
                    icon:'pi pi-book',
                    items: [
                        {
                            label: 'Income',
                            icon:'pi pi-fw pi-user-plus',
                            routerLink:["/income"],
          
                        },
                        {
                            label: 'Expense',
                            icon:'pi pi-fw pi-user-minus',
                            routerLink:["/expense"],
                        },
    
                    ]
                    },
                    {
                        label: 'Register',
                        icon:'pi pi-book',
                        routerLink:["/registers"],
                        },
                        {
                            label: 'Settings',
                            icon:'pi pi-book',
                            routerLink:["/settings"]
                            },
      ]
      this.sideBar()
  }


  sideBar(){
    let sidebar = document.querySelector(".sidebar");
    let closeBtn = document.querySelector(".openbar");
    let searchBtn = document.querySelector(".bx-search");
    let dash = document.querySelectorAll(".dash");
    
    
    // closeBtn.addEventListener("click", ()=>{
    //   sidebar.classList.toggle("open");
    // });
    
    searchBtn.addEventListener("click", ()=>{ // Sidebar open when you click on the search iocn
      sidebar.classList.toggle("open");
    });
    

     dash.forEach((item)=>{
      item.addEventListener("click", ()=>{ // Sidebar open when you click on the search iocn
        sidebar.classList.toggle("open");
      });
     })



    

    if(sidebar.classList.contains("open")){
      closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");//replacing the iocns class
    }else {
      closeBtn.classList.replace("bx-menu-alt-right","bx-menu");//replacing the iocns class
    }
  }



}
