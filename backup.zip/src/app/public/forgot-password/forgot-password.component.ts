//import { faLock } from './../../../../node_modules/@fortawesome/free-solid-svg-icons/faLock.d';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  //faLock = faLock; 
  constructor() { }

  ngOnInit(): void {
  }

}
