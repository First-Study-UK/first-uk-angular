export const environment = {
  firebase: {
    projectId: 'first-study-f4c8f',
    appId: '1:510464303608:web:6bb669567632fe2518b60d',
    storageBucket: 'first-study-f4c8f.appspot.com',
    locationId: 'europe-west',
    apiKey: 'AIzaSyCt4owBYBJCXgwgFke9Q38XBVVEBih8Wro',
    authDomain: 'first-study-f4c8f.firebaseapp.com',
    messagingSenderId: '510464303608',
    measurementId: 'G-BDZJ6ZW9BG',
  },
  baseUrl:'',
  production: true
};
